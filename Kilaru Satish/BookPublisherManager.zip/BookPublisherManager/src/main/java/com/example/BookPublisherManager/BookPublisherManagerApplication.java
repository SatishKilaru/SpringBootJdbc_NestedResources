package com.example.BookPublisherManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookPublisherManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookPublisherManagerApplication.class, args);
	}

}
