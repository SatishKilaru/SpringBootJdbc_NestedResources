package com.example.BookPublisherManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookPublisherManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
